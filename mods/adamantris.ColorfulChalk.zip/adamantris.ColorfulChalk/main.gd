extends Node

signal picker_visible

export var color_id: Dictionary

enum send_type{
	RELIABLE = 8,
	UNRELIABLE = 0,
	UNRELIABLE_FAST = 4,
}

const COLOR_CHANNEL = 10
const protocol_version = 4

onready var canv_paths = {
	"1": "/root/world/Viewport/main/map/main_map/zones/main_zone/chalk_zones/chalk_canvas/Viewport/TileMap",
	"2": "/root/world/Viewport/main/map/main_map/zones/main_zone/chalk_zones/chalk_canvas2/Viewport/TileMap",
	"3": "/root/world/Viewport/main/map/main_map/zones/main_zone/chalk_zones/chalk_canvas3/Viewport/TileMap",
	"4": "/root/world/Viewport/main/map/main_map/zones/main_zone/chalk_zones/chalk_canvas4/Viewport/TileMap"
}

onready var Lure = get_node("/root/SulayreLure")
onready var Players = get_node_or_null("/root/ToesSocks/Players")
onready var Chat = get_node_or_null("/root/ToesSocks/Chat")


onready var color_picker = preload("res://mods/adamantris.ColorfulChalk/scenes/color_picker.tscn")
onready var file_scene = preload("res://mods/adamantris.ColorfulChalk/scenes/image_loader/file_dialog.tscn")

var canvas_TileMap: TileMap
var canvas_TileSet: TileSet
var color_dict: Dictionary = {}
var selected_chalk_color
var Lure_chalk_dict
var Lure_chalk_resource

var mod_user_list = []

var packet_timer: float = 0.0
var packet_thread: Thread
var packet_semaphore: Semaphore
var packet_mutex: Mutex
var kill_threads = false

var tile_thread: Thread

export onready var atlas_img: Image
export onready var atlas_tex: ImageTexture
var color_slot = 0

func _ready():
	yield(get_tree().create_timer(1.0), "timeout")
	
	self.add_child(file_scene.instance())
	
	var file_manager = Directory.new()
	if not file_manager.dir_exists("user://colorfulchalk_images"):
		print("Images folder doesn't exist, creating new folder.")
		file_manager.make_dir("user://colorfulchalk_images")
	
	Chat.connect("player_messaged", self, "chat_command")
	Players.connect("ingame", self, "ingame")
	Players.connect("player_removed", self, "player_removed")
	Lure.add_content("adamantris.ColorfulChalk", "Rainbow Chalk", "res://mods/adamantris.ColorfulChalk/resources/chalk_rainbow.tres", [Lure.LURE_FLAGS.FREE_UNLOCK])
	
	atlas_img = Image.new()
	atlas_img.create(512, 512, false, Image.FORMAT_RGBA8)
	
	atlas_tex = ImageTexture.new()
	atlas_tex.create_from_image(atlas_img)
	atlas_tex.flags += Texture.FLAG_CONVERT_TO_LINEAR
	
	InputMap.add_action("toggle_picker")
	var keyevent = InputEventKey.new()
	keyevent.scancode = KEY_P
	InputMap.action_add_event("toggle_picker", keyevent)
	
	packet_semaphore = Semaphore.new()
	packet_mutex = Mutex.new()
	packet_thread = Thread.new()
	packet_thread.start(self, "read_packets")

func _process(delta):
	if not Players.in_game:
		return
	
	packet_timer += delta
	if packet_timer >= 0.2:
		packet_semaphore.post()
		packet_timer = 0.0

func ingame():
	Lure_chalk_dict = Lure.item_list.get("adamantris.ColorfulChalk.Rainbow Chalk")
	Lure_chalk_resource = Lure_chalk_dict.get("resource")
	lobby_joined()
	
	canvas_TileMap = get_node("/root/world/Viewport/main/map/main_map/zones/main_zone/chalk_zones/chalk_canvas/Viewport/TileMap")
	canvas_TileSet = canvas_TileMap.get_tileset()
	
	self.add_child(color_picker.instance())

func chat_command(message: String, player, is_self):

			
	if is_self == true and message.begins_with("!debug_save"):
		atlas_img.save_png("user://colorfulchalk_images/test.png")
		print("hopefully saved a png lol")
	
	
	#this is experimental, i just wanna see if its possible
	if is_self == true and message.begins_with("!save"):
		
		var canv_id = message.get_slice(" ", 1)
		
		if not int(canv_id) in [1, 2, 3, 4]:
			print("im yelling at u you there are only 4 chalk spots")
			PlayerData._send_notification("invalid canvas ID, only numbers between 1 and 4 are valid", 1)
			return
		

		
		var canv_tilemap_node = get_node(canv_paths.get(canv_id))
		var canv_tileset_node = canv_tilemap_node.get_tileset()
		
		atlas_img.lock()
		var tileset_cells = canv_tilemap_node.get_used_cells()
		
		var temp_image = Image.new()
		temp_image.create(200, 200, false, Image.FORMAT_RGBA8)
		
		temp_image.lock()
		#print("this is the tileset cells used (vec2 array): " + str(tileset_cells))
		#temp_image.lock()
		
		
		for cell in tileset_cells:
			#print(str(canvas_TileMap.get_cellv(cell)))
			var canv_tile_tex = canvas_TileSet.tile_get_texture(canv_tilemap_node.get_cellv(cell))
			
			var pixel_color
			#print(canv_tile_tex)
			#print(str(canv_tile_tex))
			if !(canv_tile_tex is AtlasTexture):
				print("this is vanilla chalk, passing")
				pass
			if canv_tile_tex is AtlasTexture:
				var canv_tile_coord = canv_tile_tex.region
				pixel_color = atlas_img.get_pixel(canv_tile_coord.position.x, canv_tile_coord.position.y)
			#print(canv_tile_coord)
			
			if pixel_color:
			
				temp_image.set_pixelv(cell, pixel_color)
				print("set pixel at " + str(cell) + " to color " + pixel_color.to_html())
				
			else:
				print("no mod chalk found, sorry")
		temp_image.save_png("user://colorfulchalk_images/canvas_" + str(int(rand_range(0.0, 100000.0))) + ".png")
		temp_image.unlock()
		atlas_img.unlock()
		
	if is_self == true and message.begins_with("!hash"):
		var hash_debug_thread = Thread.new()
		
		var debug_hash = var2bytes("bepis")
		print("created debug hash: " + debug_hash.hex_encode())
		
		hash_debug_thread.start(self, "compute_hash", debug_hash)
		var hashed = hash_debug_thread.wait_to_finish()
		
		print("hashed data: " + str(hashed.hex_encode()))

# --- START: FINAL, OPTIMIZED COLOR PROCESSING LOGIC ---

func add_color_data(color_data):
	if tile_thread and tile_thread.is_active():
		print("A tile creation process is already running. Ignoring new request.")
		return

	print("Starting background thread to process colors and tileset...")
	tile_thread = Thread.new()
	var thread_data = {
		"pixels": color_data.get("pixels"),
		"existing_colors": color_dict.keys(),
		"loader_path": color_data.get("loader_path"),
		"tileset_duplicate": canvas_TileSet.duplicate(),
		"atlas_img_duplicate": atlas_img.duplicate(),
		"current_color_slot": color_slot
	}
	tile_thread.start(self, "_thread_process_new_colors", thread_data)

func _thread_process_new_colors(data: Dictionary):
	var pixels: Array = data.get("pixels")
	var existing_colors: Array = data.get("existing_colors")
	var loader_path = data.get("loader_path")
	var tileset_duplicate: TileSet = data.get("tileset_duplicate")
	var atlas_img_duplicate: Image = data.get("atlas_img_duplicate")
	var current_color_slot: int = data.get("current_color_slot")
	
	var unique_new_colors = []
	var seen_colors = {}
	for color_html in existing_colors:
		seen_colors[color_html] = true

	for pixel_color in pixels:
		var color_html = pixel_color.to_html(false)
		if not seen_colors.has(color_html):
			seen_colors[color_html] = true
			unique_new_colors.append(pixel_color)

	var new_color_map = {}
	if not unique_new_colors.empty():
		print("Thread: processing %d new colors." % unique_new_colors.size())
		atlas_img_duplicate.lock()
		var image_size = 512

		for color in unique_new_colors:
			var color_x = current_color_slot % image_size
			var color_y = int(current_color_slot / image_size)
			
			atlas_img_duplicate.set_pixel(color_x, color_y, color)
			
			var new_atlas_tex = AtlasTexture.new()
			# NOTE: The atlas texture itself can't be passed to the thread, 
			# so we create a placeholder. It will be reassigned on the main thread.
			new_atlas_tex.region = Rect2(color_x, color_y, 1, 1)
			
			var new_tile_id = tileset_duplicate.get_last_unused_tile_id()
			tileset_duplicate.create_tile(new_tile_id)
			
			var color_string = color.to_html(false)
			tileset_duplicate.tile_set_name(new_tile_id, color_string)
			tileset_duplicate.tile_set_texture(new_tile_id, new_atlas_tex)
			
			new_color_map[color_string] = new_tile_id
			current_color_slot += 1

		atlas_img_duplicate.unlock()

	var results = {
		"new_tileset": tileset_duplicate,
		"new_atlas_img": atlas_img_duplicate,
		"new_color_map": new_color_map,
		"new_color_slot": current_color_slot,
		"loader_path": loader_path
	}
	call_deferred("_apply_thread_results", results)

func _apply_thread_results(results: Dictionary):
	print("Applying thread results to main game...")
	var new_tileset = results.get("new_tileset")
	var new_atlas_img = results.get("new_atlas_img")
	var new_color_map = results.get("new_color_map")
	var new_color_slot = results.get("new_color_slot")
	var loader_path = results.get("loader_path")

	# Re-assign the atlas texture to all new tiles on the main thread
	for color_string in new_color_map:
		var tile_id = new_color_map[color_string]
		var atlas_tex_instance = new_tileset.tile_get_texture(tile_id) as AtlasTexture
		if atlas_tex_instance:
			atlas_tex_instance.atlas = self.atlas_tex

	# Apply changes to the game state
	canvas_TileMap.tile_set = new_tileset
	self.canvas_TileSet = new_tileset
	self.atlas_img = new_atlas_img
	self.atlas_tex.create_from_image(self.atlas_img)
	self.color_dict.merge(new_color_map, true)
	self.color_slot = new_color_slot

	print("Finished applying results.")

	if not new_color_map.empty():
		var color_poolbytes = var2bytes(["create_new_color", new_color_map, protocol_version])
		for player in mod_user_list:
			Steam.sendMessageToUser(player, color_poolbytes, send_type.RELIABLE, COLOR_CHANNEL)

	if loader_path:
		var loader_logic = get_node_or_null(loader_path)
		if loader_logic:
			loader_logic.actually_paint_tiles_on_map()
		else:
			print("ERROR: Could not find loader_logic at path: " + loader_path)
		
	if tile_thread and tile_thread.is_active():
		tile_thread.wait_to_finish()
	print("Process finished and thread cleaned up.")

# --- END: FINAL LOGIC ---

func lobby_joined():
	var color_handshake = "hello_lobby_i_just_joined"
	var hello_poolbyte = var2bytes(["color_handshake", color_handshake, protocol_version])
	for connection_entry in Network.OPEN_CONNECTIONS:
		var steam_id = connection_entry
		Steam.sendMessageToUser(str(steam_id), hello_poolbyte, send_type.RELIABLE, COLOR_CHANNEL)

func request_dict():
	if mod_user_list.size() >= 1:
		yield(get_tree().create_timer(0.5), "timeout")
		var request_poolbyte = var2bytes(["requested_dict", "pls send dict", protocol_version])
		Steam.sendMessageToUser(mod_user_list[0], request_poolbyte, send_type.RELIABLE, COLOR_CHANNEL)

func player_removed(player_node):
	if player_node.owner_id in mod_user_list:
		mod_user_list.erase(player_node.owner_id)
	elif player_node.owner_id == Network.STEAM_ID:
		clear_color()

func clear_color():
	atlas_img.lock()
	atlas_img.fill(Color.transparent)
	atlas_img.unlock()
	atlas_tex.create_from_image(atlas_img)
	color_slot = 0
	
	for tile in color_dict.keys():
		canvas_TileSet.remove_tile(color_dict.get(tile))
	
	color_dict = {}
	mod_user_list = []

func compute_hash(hash_data) -> PoolByteArray:
	var hash_compute = HashingContext.new()
	hash_compute.start(HashingContext.HASH_MD5)
	hash_compute.update(hash_data)
	return hash_compute.finish()
	
func read_packets():
	while true:
		packet_semaphore.wait()
		packet_mutex.lock()
		var message_array = Steam.receiveMessagesOnChannel(COLOR_CHANNEL, 10)
		packet_mutex.unlock()
		
		for message in message_array:
			var decoded = bytes2var(message.get("payload"))
			var sender_steam_id = message.get("identity").get_slice(":", 1)
			
			if decoded.size() < 3 or decoded[2] != protocol_version:
				print("Discarding packet with wrong protocol version.")
				continue

			var packet_command = decoded[0]
			match packet_command:
				"color_handshake":
					var response_poolbyte = var2bytes(["handshake_response", "hello_back", protocol_version])
					packet_mutex.lock()
					if not sender_steam_id in mod_user_list:
						mod_user_list.append(sender_steam_id)
					packet_mutex.unlock()
					Steam.call_deferred("sendMessageToUser", sender_steam_id, response_poolbyte, send_type.RELIABLE, COLOR_CHANNEL)
				
				"handshake_response":
					packet_mutex.lock()
					if not sender_steam_id in mod_user_list:
						mod_user_list.append(sender_steam_id)
					packet_mutex.unlock()
					request_dict()
				
				"requested_dict":
					var dict_poolbyte = var2bytes(["received_dict", color_dict, protocol_version])
					Steam.call_deferred("sendMessageToUser", sender_steam_id, dict_poolbyte, send_type.RELIABLE, COLOR_CHANNEL)
				
				"received_dict":
					var received_dict = decoded[1]
					var new_colors_from_net = []
					for color_string in received_dict.keys():
						if not color_dict.has(color_string):
							new_colors_from_net.append(Color(color_string))
					if not new_colors_from_net.empty():
						call_deferred("_apply_thread_results", {"new_color_map": received_dict})

				"create_new_color":
					var remote_color_dict = decoded[1]
					var new_colors_from_net = []
					for color_string in remote_color_dict.keys():
						if not color_dict.has(color_string):
							new_colors_from_net.append(Color(color_string))
					if not new_colors_from_net.empty():
						call_deferred("_apply_thread_results", {"new_color_map": remote_color_dict})
